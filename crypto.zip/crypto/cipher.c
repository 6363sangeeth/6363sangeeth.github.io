#include <stdio.h>
#include <ctype.h>

void caesarcipher(char *text,int key)
{
  int i=0;
  char ch;
  key=key%26;
  
  while(text[i] != '\0')
  {
    ch=text[i];
    if(isalpha(ch))
    {
      char base=isupper(ch)?'A':'a';
      text[i]=(ch-base+key)%26+base;
    }
    i++;
  }
}

int main()
{
  char text[100];
  int key;
  printf("Enter text to encrypt:");
  fgets(text,sizeof(text),stdin);
  printf("Enter key(shift):");
  scanf("%d",&key);
  caesarcipher(text,key);
  printf("Encrypted text:%s\n",text);
  return 0;

}
