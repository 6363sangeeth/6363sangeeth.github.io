#include <stdio.h>
#include <string.h>
#include <ctype.h>

char matrix[5][5];

void buildMatrix(char *key) {
    int used[26] = {0}, k = 0;
    used['J' - 'A'] = 1;
    for (int i = 0; key[i]; i++) {
        char ch = toupper(key[i]) == 'J' ? 'I' : toupper(key[i]);
        if (!used[ch - 'A'] && isalpha(ch)) {
            matrix[k / 5][k % 5] = ch;
            used[ch - 'A'] = 1; k++;
        }
    }
    for (char ch = 'A'; ch <= 'Z'; ch++)
        if (!used[ch - 'A']) {
            matrix[k / 5][k % 5] = ch;
            used[ch - 'A'] = 1; k++;
        }
}

void find(char c, int *r, int *c_) {
    if (c == 'J') c = 'I';
    for (int i = 0; i < 5; i++)
        for (int j = 0; j < 5; j++)
            if (matrix[i][j] == c) { *r = i; *c_ = j; return; }
}

void playfair(char *in, char *out, int mode) {
    int len = 0;
    char temp[100] = {0};
    for (int i = 0; in[i]; i++)
        if (isalpha(in[i])) temp[len++] = toupper(in[i]) == 'J' ? 'I' : toupper(in[i]);

    char text[100] = {0}; int j = 0;
    for (int i = 0; i < len; i += 2) {
        text[j++] = temp[i];
        if (i + 1 < len)
            text[j++] = temp[i] == temp[i + 1] ? 'X' : temp[i + 1];
    }
    if (j % 2 != 0) text[j++] = 'X';

    for (int i = 0; i < j; i += 2) {
        int r1, c1, r2, c2;
        find(text[i], &r1, &c1); find(text[i + 1], &r2, &c2);
        if (r1 == r2) {
            out[i] = matrix[r1][(c1 + mode + 5) % 5];
            out[i + 1] = matrix[r2][(c2 + mode + 5) % 5];
        } else if (c1 == c2) {
            out[i] = matrix[(r1 + mode + 5) % 5][c1];
            out[i + 1] = matrix[(r2 + mode + 5) % 5][c2];
        } else {
            out[i] = matrix[r1][c2];
            out[i + 1] = matrix[r2][c1];
        }
    }
    out[j] = '\0';
}

int main() {
    char key[50], text[100], enc[100], dec[100];
    printf("Key: "); scanf("%s", key);
    printf("Text: "); scanf("%s", text);
    buildMatrix(key);
    playfair(text, enc, 1);
    playfair(enc, dec, -1);
    printf("Encrypted: %s\nDecrypted: %s\n", enc, dec);
    return 0;
}


