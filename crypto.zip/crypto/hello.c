#include <stdio.h>
#include <string.h>

int main()
{

  char str[]="HelloWorld";
  char result[100];
  int i=0;
  
  while(str[i] != '\0')
  {
    result[i]= str[i]^0;
    i++;
  }
  
  result[i] = '\0';
  
  printf("Result of the Characters XOR with 0 \n %s\n ",result);

return 0;

}
