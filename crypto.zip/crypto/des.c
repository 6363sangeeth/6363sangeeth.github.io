#include <stdio.h>
#include <stdint.h>
#include <string.h>

// Initial and Final Permutations, S-boxes, and Key Schedule (tables omitted for brevity)
// See any full DES reference for the actual table data.

// -- FILL IN TABLES HERE or see open-source links below --

// Sample placeholder tables (must be filled with correct values in real code)
int IP[] = {/*...*/};          // Initial Permutation table (64 entries)
int FP[] = {/*...*/};          // Final Permutation table (64 entries)
int E[] = {/*...*/};           // Expansion table (48 entries)
int S[8][4][16] = {/*...*/};   // DES S-boxes (8 x 4 x 16 entries)
int P[] = {/*...*/};           // Permutation P (32 entries)
int PC1[] = {/*...*/};         // Key permutation (56 entries)
int PC2[] = {/*...*/};         // Compression permutation (48 entries)
int SHIFTS[] = {/*...*/};      // Number of left shifts in each round (16 entries)

// Helper functions for permutation, key scheduling, rounds, etc.

// -- Helper function implementations go here, as in open-source reference below --

int main() {
    uint8_t key[8];      // 8-byte DES key
    uint8_t plaintext[8];// 8-byte plaintext block
    uint8_t ciphertext[8];
    uint8_t decrypted[8];

    printf("Enter 8-character key: ");
    fgets((char*)key, 9, stdin);

    printf("Enter 8-character plaintext: ");
    fgets((char*)plaintext, 9, stdin);

    // Pad with zeros if input is short
    for (int i = strlen((char*)key); i < 8; i++) key[i] = 0;
    for (int i = strlen((char*)plaintext); i < 8; i++) plaintext[i] = 0;

    // Key schedule
    // -- Key schedule code here --

    // Encrypt
    // des_encrypt(plaintext, ciphertext, key_schedule);

    // Decrypt
    // des_decrypt(ciphertext, decrypted, key_schedule);

    printf("Ciphertext: ");
    for (int i = 0; i < 8; ++i) printf("%02X", ciphertext[i]);
    printf("\n");

    printf("Decrypted: %s\n", decrypted);

    return 0;
}






