#include <stdio.h>
#include <string.h>

int modInv(int a) {
    a %= 26;
    for (int i = 1; i < 26; i++)
        if ((a * i) % 26 == 1)
            return i;
    return -1;
}

void encrypt(char *pt, char *ct, int k[2][2]) {
    for (int i = 0; i < strlen(pt); i += 2) {
        ct[i]   = ((k[0][0]*(pt[i]-'A') + k[0][1]*(pt[i+1]-'A')) % 26) + 'A';
        ct[i+1] = ((k[1][0]*(pt[i]-'A') + k[1][1]*(pt[i+1]-'A')) % 26) + 'A';
    }
}

int decrypt(char *ct, char *dt, int k[2][2]) {
    int d = (k[0][0]*k[1][1] - k[0][1]*k[1][0] + 26) % 26;
    int inv = modInv(d);
    if (inv == -1) return 0;

    int ik[2][2] = {
        {k[1][1]*inv % 26, (26 - k[0][1])*inv % 26},
        {(26 - k[1][0])*inv % 26, k[0][0]*inv % 26}
    };

    for (int i = 0; i < strlen(ct); i += 2) {
        dt[i]   = ((ik[0][0]*(ct[i]-'A') + ik[0][1]*(ct[i+1]-'A')) % 26) + 'A';
        dt[i+1] = ((ik[1][0]*(ct[i]-'A') + ik[1][1]*(ct[i+1]-'A')) % 26) + 'A';
    }
    return 1;
}

int main() {
    char pt[100], ct[100] = {0}, dt[100] = {0};
    int key[2][2];

    printf("Enter 2x2 key matrix (4 integers):\n");
    scanf("%d%d%d%d", &key[0][0], &key[0][1], &key[1][0], &key[1][1]);
    while (getchar() != '\n');

    printf("Enter plaintext (A-Z only): ");
    scanf("%s", pt);

    // Convert to uppercase
    for (int i = 0; pt[i]; i++)
        if (pt[i] >= 'a' && pt[i] <= 'z')
            pt[i] = pt[i] - 'a' + 'A';

    if (strlen(pt) % 2 != 0)
        strcat(pt, "X");

    encrypt(pt, ct, key);
    printf("Encrypted text: %s\n", ct);

    if (decrypt(ct, dt, key))
        printf("Decrypted text: %s\n", dt);
    else
        printf("Decryption failed: Key matrix is not invertible modulo 26.\n");

    return 0;
}

