#include <stdio.h>
#include <ctype.h>
#include <string.h>

void caesarcipher(char *text, int key)
{
    int i = 0;
    char ch;
    key = key % 26;

    while (text[i] != '\0')
    {
        ch = text[i];
        if (isalpha(ch))
        {
            char base = isupper(ch) ? 'A' : 'a';
            text[i] = (ch - base + key + 26) % 26 + base;
        }
        i++;
    }
}

int main()
{
    char original[100];
    char encrypted[100];
    char decrypted[100];
    int key;

    printf("Enter text: ");
    fgets(original, sizeof(original), stdin);

    size_t len = strlen(original);
    if (len > 0 && original[len - 1] == '\n') {
        original[len - 1] = '\0';
    }

    printf("Enter key (shift): ");
    scanf("%d", &key);

    strcpy(encrypted, original);
    strcpy(decrypted, original);

    caesarcipher(encrypted, key);
    printf("Encrypted text: %s\n", encrypted);
    caesarcipher(encrypted, -key); 
    printf("Decrypted text: %s\n", encrypted);

    return 0;
}

