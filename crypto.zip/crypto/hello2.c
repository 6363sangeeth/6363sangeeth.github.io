#include <stdio.h>

int main() {
    char str[]= "helloworld";
    int i = 0;

    printf("Original string: %s\n", str);

    while (str[i] != '\0') {
        str[i]=str[i] & 127;
        i++;
    }
    printf("Result after AND with 127:%s\n",str);

    i = 0;
    while (str[i] != '\0') {
        str[i]=str[i] | 127;
        i++;
    }
    printf("Result after OR with 127:%s\n",str);

    i = 0;
    while (str[i] != '\0') {
        str[i]=str[i] ^ 127;
        i++;
    }
    printf("Result after XOR with 127:%s\n",str);

    return 0;
} 

